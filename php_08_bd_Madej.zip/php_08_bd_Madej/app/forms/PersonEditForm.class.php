<?php

namespace app\forms;

class PersonEditForm {
	public $id;
	public $name;
	public $surname;
	public $birthdate;
	public $numer_tel;
}